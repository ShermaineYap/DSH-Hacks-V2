Fasa: dengue at home, one day at a time (DSH Hacks V2, AI x Healthcare)
Shermaine Yap

Fasa-one-page.pdf   One-page project description
source/             Complete source code (same as GitHub), tests, evaluation scripts and results
Live app            https://dsh-hacks-v2-jade.vercel.app
Evidence page       https://dsh-hacks-v2-jade.vercel.app/evidence
Code                https://github.com/ShermaineYap/DSH-Hacks-V2
Demo video          https://youtu.be/CiH1GO_0nOQ
